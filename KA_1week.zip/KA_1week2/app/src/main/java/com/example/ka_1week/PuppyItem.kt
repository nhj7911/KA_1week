package com.example.ka_1week

data class PuppyItem(
    val puppy_img : Int,
    val puppy_name : String,
    val puppy_age : String,
    val puppy_feature : String,
    val puppy_place : String
)